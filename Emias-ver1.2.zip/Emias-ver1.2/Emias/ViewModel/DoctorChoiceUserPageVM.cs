﻿using Emias.Interfaces;
using Emias.View;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;

namespace Emias.ViewModel
{
    public class DoctorChoiceUserPageVM 
    {
        private Button currentlyHighlightedButton;
        private Button currentlyHighlightedButton1;
        private Brush selectedColor = (Brush)new BrushConverter().ConvertFromString("#007BFE");
        public DoctorChoiceUserPageVM(INavigationService navigation)
        {
            DateTime date = DateTime.Now;
            CultureInfo culture = new CultureInfo("ru-RU");

            DateTime newDate = date.AddDays(0);
            DateTime newDate1 = date.AddDays(+1);
            DateTime newDate2 = date.AddDays(+2);
            DateTime newDate3 = date.AddDays(+3);
            DateTime newDate4 = date.AddDays(+4);
            DateTime newDate5 = date.AddDays(+5);
            DateTime newDate6 = date.AddDays(+6);
            DateTime newDate7 = date.AddDays(+7);
            DateTime newDate8 = date.AddDays(+8);
            DateTime newDate9 = date.AddDays(+9);
            DateTime newDate10 = date.AddDays(+10);
            DateTime newDate11 = date.AddDays(+11);
            DateTime newDate12 = date.AddDays(+12);
            DateTime newDate13 = date.AddDays(+13);

            string monthName = culture.DateTimeFormat.GetMonthName(newDate.Month);
            string monthName1 = culture.DateTimeFormat.GetMonthName(newDate1.Month);
            string monthName2 = culture.DateTimeFormat.GetMonthName(newDate2.Month);
            string monthName3 = culture.DateTimeFormat.GetMonthName(newDate3.Month);
            string monthName4 = culture.DateTimeFormat.GetMonthName(newDate4.Month);
            string monthName5 = culture.DateTimeFormat.GetMonthName(newDate5.Month);
            string monthName6 = culture.DateTimeFormat.GetMonthName(newDate6.Month);

            string dayOfWeek = culture.DateTimeFormat.GetDayName(newDate.DayOfWeek).Substring(0, 2);
            string dayOfWeek1 = culture.DateTimeFormat.GetDayName(newDate1.DayOfWeek).Substring(0, 2);
            string dayOfWeek2 = culture.DateTimeFormat.GetDayName(newDate2.DayOfWeek).Substring(0, 2);
            string dayOfWeek3 = culture.DateTimeFormat.GetDayName(newDate3.DayOfWeek).Substring(0, 2);
            string dayOfWeek4 = culture.DateTimeFormat.GetDayName(newDate4.DayOfWeek).Substring(0, 2);
            string dayOfWeek5 = culture.DateTimeFormat.GetDayName(newDate5.DayOfWeek).Substring(0, 2);
            string dayOfWeek6 = culture.DateTimeFormat.GetDayName(newDate6.DayOfWeek).Substring(0, 2);

            string formattedDate = $"{newDate.Day} {monthName} {dayOfWeek}.";
            string formattedDate2 = $"{newDate1.Day} {monthName1} {dayOfWeek1}.";
            string formattedDate3 = $"{newDate2.Day} {monthName2} {dayOfWeek2}.";
            string formattedDate4 = $"{newDate3.Day} {monthName3} {dayOfWeek3}.";
            string formattedDate5 = $"{newDate4.Day} {monthName4} {dayOfWeek4}.";
            string formattedDate6 = $"{newDate5.Day} {monthName5} {dayOfWeek5}.";
            string formattedDate7 = $"{newDate6.Day} {monthName6} {dayOfWeek6}.";

            string formattedDate8 = $"{newDate7.Day} {monthName} {dayOfWeek}.";
            string formattedDate9 = $"{newDate8.Day} {monthName1} {dayOfWeek1}.";
            string formattedDate10 = $"{newDate9.Day} {monthName2} {dayOfWeek2}.";
            string formattedDate11 = $"{newDate10.Day} {monthName3} {dayOfWeek3}.";
            string formattedDate12 = $"{newDate11.Day} {monthName4} {dayOfWeek4}.";
            string formattedDate13 = $"{newDate12.Day} {monthName5} {dayOfWeek5}.";
            string formattedDate14 = $"{newDate13.Day} {monthName6} {dayOfWeek6}.";

           


        
        }
    }
}
