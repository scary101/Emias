﻿using Emias.Service;
using Emias.ViewModel;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Emias.View
{
    /// <summary>
    /// Логика взаимодействия для DoctorChoiceUserPage.xaml
    /// </summary>
    public partial class DoctorChoiceUserPage : Page
    {
        private ServiceNavigation _navigationService;
        private Button currentlyHighlightedButton;
        private Button currentlyHighlightedButton1;
        private Brush selectedColor = (Brush)new BrushConverter().ConvertFromString("#007BFE");
        


        public DoctorChoiceUserPage(ServiceNavigation navigationService)
        {
            InitializeComponent();

            _navigationService = navigationService;
            DataContext = new DoctorChoiceUserPageVM(_navigationService);

            DateTime date = DateTime.Now;
            CultureInfo culture = new CultureInfo("ru-RU");

            DateTime newDate = date.AddDays(0);
            DateTime newDate1 = date.AddDays(+1);
            DateTime newDate2 = date.AddDays(+2);
            DateTime newDate3 = date.AddDays(+3);
            DateTime newDate4 = date.AddDays(+4);
            DateTime newDate5 = date.AddDays(+5);
            DateTime newDate6 = date.AddDays(+6);
            DateTime newDate7 = date.AddDays(+7);
            DateTime newDate8 = date.AddDays(+8);
            DateTime newDate9 = date.AddDays(+9);
            DateTime newDate10 = date.AddDays(+10);
            DateTime newDate11 = date.AddDays(+11);
            DateTime newDate12 = date.AddDays(+12);
            DateTime newDate13 = date.AddDays(+13);

            string monthName = culture.DateTimeFormat.GetMonthName(newDate.Month);
            string monthName1 = culture.DateTimeFormat.GetMonthName(newDate1.Month);
            string monthName2 = culture.DateTimeFormat.GetMonthName(newDate2.Month);
            string monthName3 = culture.DateTimeFormat.GetMonthName(newDate3.Month);
            string monthName4 = culture.DateTimeFormat.GetMonthName(newDate4.Month);
            string monthName5 = culture.DateTimeFormat.GetMonthName(newDate5.Month);
            string monthName6 = culture.DateTimeFormat.GetMonthName(newDate6.Month);

            string dayOfWeek = culture.DateTimeFormat.GetDayName(newDate.DayOfWeek).Substring(0, 2);
            string dayOfWeek1 = culture.DateTimeFormat.GetDayName(newDate1.DayOfWeek).Substring(0, 2);
            string dayOfWeek2 = culture.DateTimeFormat.GetDayName(newDate2.DayOfWeek).Substring(0, 2);
            string dayOfWeek3 = culture.DateTimeFormat.GetDayName(newDate3.DayOfWeek).Substring(0, 2);
            string dayOfWeek4 = culture.DateTimeFormat.GetDayName(newDate4.DayOfWeek).Substring(0, 2);
            string dayOfWeek5 = culture.DateTimeFormat.GetDayName(newDate5.DayOfWeek).Substring(0, 2);
            string dayOfWeek6 = culture.DateTimeFormat.GetDayName(newDate6.DayOfWeek).Substring(0, 2);

            string formattedDate = $"{newDate.Day} {monthName} {dayOfWeek}.";
            string formattedDate2 = $"{newDate1.Day} {monthName1} {dayOfWeek1}.";
            string formattedDate3 = $"{newDate2.Day} {monthName2} {dayOfWeek2}.";
            string formattedDate4 = $"{newDate3.Day} {monthName3} {dayOfWeek3}.";
            string formattedDate5 = $"{newDate4.Day} {monthName4} {dayOfWeek4}.";
            string formattedDate6 = $"{newDate5.Day} {monthName5} {dayOfWeek5}.";
            string formattedDate7 = $"{newDate6.Day} {monthName6} {dayOfWeek6}.";

            string formattedDate8 = $"{newDate7.Day} {monthName} {dayOfWeek}.";
            string formattedDate9 = $"{newDate8.Day} {monthName1} {dayOfWeek1}.";
            string formattedDate10 = $"{newDate9.Day} {monthName2} {dayOfWeek2}.";
            string formattedDate11 = $"{newDate10.Day} {monthName3} {dayOfWeek3}.";
            string formattedDate12 = $"{newDate11.Day} {monthName4} {dayOfWeek4}.";
            string formattedDate13 = $"{newDate12.Day} {monthName5} {dayOfWeek5}.";
            string formattedDate14 = $"{newDate13.Day} {monthName6} {dayOfWeek6}.";

            d1.Content = formattedDate ;
            d2.Content = formattedDate2;
            d3.Content = formattedDate3;
            d4.Content = formattedDate4;
            d5.Content = formattedDate5;
            d6.Content = formattedDate6;
            d7.Content = formattedDate7;
            d8.Content = formattedDate8;
            d9.Content = formattedDate9;
            d10.Content = formattedDate10;
            d11.Content = formattedDate11;
            d12.Content = formattedDate12;
            d13.Content = formattedDate13;
            d14.Content = formattedDate14;


        }

        private void d1_Click(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton != null)
            {
                currentlyHighlightedButton.Background = Brushes.LightGray;
            }

            // Определение кнопки, которая была нажата
            Button clickedButton = sender as Button;

            // Установка цвета фона нажатой кнопки
            clickedButton.Background = selectedColor;

            // Обновление текущей выделенной кнопки
            currentlyHighlightedButton = clickedButton;
        }

        private void d2_Click(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton != null)
            {
                currentlyHighlightedButton.Background = Brushes.LightGray;
            }

            // Определение кнопки, которая была нажата
            Button clickedButton = sender as Button;

            // Установка цвета фона нажатой кнопки
            clickedButton.Background = selectedColor;

            // Обновление текущей выделенной кнопки
            currentlyHighlightedButton = clickedButton;
        }

        private void d3_Click(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton != null)
            {
                currentlyHighlightedButton.Background = Brushes.LightGray;
            }

            // Определение кнопки, которая была нажата
            Button clickedButton = sender as Button;

            // Установка цвета фона нажатой кнопки
            clickedButton.Background = selectedColor;

            // Обновление текущей выделенной кнопки
            currentlyHighlightedButton = clickedButton;
        }

        private void d4_Click(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton != null)
            {
                currentlyHighlightedButton.Background = Brushes.LightGray;
            }

          
            Button clickedButton = sender as Button;

           
            clickedButton.Background = selectedColor;

           
            currentlyHighlightedButton = clickedButton;
        }

        private void d5_Click(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton != null)
            {
                currentlyHighlightedButton.Background = Brushes.LightGray;
            }


            Button clickedButton = sender as Button;


            clickedButton.Background = selectedColor;


            currentlyHighlightedButton = clickedButton;
        }

        private void d6_Click(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton != null)
            {
                currentlyHighlightedButton.Background = Brushes.LightGray;
            }


            Button clickedButton = sender as Button;


            clickedButton.Background = selectedColor;


            currentlyHighlightedButton = clickedButton;
        }

        private void d7_Click(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton != null)
            {
                currentlyHighlightedButton.Background = Brushes.LightGray;
            }


            Button clickedButton = sender as Button;


            clickedButton.Background = selectedColor;


            currentlyHighlightedButton = clickedButton;
        }

        private void d8_Click(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton != null)
            {
                currentlyHighlightedButton.Background = Brushes.LightGray;
            }


            Button clickedButton = sender as Button;


            clickedButton.Background = selectedColor;


            currentlyHighlightedButton = clickedButton;
        }

        private void d9_Click(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton != null)
            {
                currentlyHighlightedButton.Background = Brushes.LightGray;
            }


            Button clickedButton = sender as Button;


            clickedButton.Background = selectedColor;


            currentlyHighlightedButton = clickedButton;
        }

        private void d10_Click(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton != null)
            {
                currentlyHighlightedButton.Background = Brushes.LightGray;
            }


            Button clickedButton = sender as Button;


            clickedButton.Background = selectedColor;


            currentlyHighlightedButton = clickedButton;
        }

        private void d11_Click(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton != null)
            {
                currentlyHighlightedButton.Background = Brushes.LightGray;
            }


            Button clickedButton = sender as Button;


            clickedButton.Background = selectedColor;


            currentlyHighlightedButton = clickedButton;
        }

        private void d12_Click(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton != null)
            {
                currentlyHighlightedButton.Background = Brushes.LightGray;
            }


            Button clickedButton = sender as Button;


            clickedButton.Background = selectedColor;


            currentlyHighlightedButton = clickedButton;
        }

        private void d13_Click(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton != null)
            {
                currentlyHighlightedButton.Background = Brushes.LightGray;
            }


            Button clickedButton = sender as Button;


            clickedButton.Background = selectedColor;


            currentlyHighlightedButton = clickedButton;
        }

        private void d14_Click(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton != null)
            {
                currentlyHighlightedButton.Background = Brushes.LightGray;
            }


            Button clickedButton = sender as Button;


            clickedButton.Background = selectedColor;


            currentlyHighlightedButton = clickedButton;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_10(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_11(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_12(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_13(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_14(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_15(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_16(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_17(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_18(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_19(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_20(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_21(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_22(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_23(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_24(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_25(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_26(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_27(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_28(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_29(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_30(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_31(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_32(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_33(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_34(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_35(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_36(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_37(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_38(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_39(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_40(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_41(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_42(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_43(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_44(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_45(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_46(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_47(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_48(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_49(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_50(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_51(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_52(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_53(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_54(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_55(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_56(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_57(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_58(object sender, RoutedEventArgs e)
        {
            if (currentlyHighlightedButton1 != null)
            {
                currentlyHighlightedButton1.Background = Brushes.LightGray;
            }


            Button clickedButton1 = sender as Button;


            clickedButton1.Background = selectedColor;


            currentlyHighlightedButton1 = clickedButton1;
        }

        private void Button_Click_59(object sender, RoutedEventArgs e)
        {
            _navigationService.NavigateTo("MainMenuUserPage");
        }
    }
}
